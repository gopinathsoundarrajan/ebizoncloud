# Terraform Introduction

- Terraform is a tool to provision infrastructure.
- Terraform when run, parses the *.tf files and generates a infrastructure state and then provisions them.
- *.tf files contains the infrastrcture as declarations using HCL syntax.
- Terraform supports variables and placeholders to reduce hardcoding values and for modularization.
- There is no ground rule for naming the *.tf files. All *.tf files under the folder where the terraform command is executed will be parsed into a single tf inmemory before applying/provisioning.
- To supply values to the variables, one should create terraform.tfvars file.
- terraform.tfstate and terraform.tfstate.backup are terraform state file which should not be deleted and should be stored in filestorage.
- .terraform folder is created by terraform executable to store plugins and modules -- this folder can be ignored while comming to code repository.

## Prerequsites

- Install terraform
- Install oci cmdline (optional)
- Run "oci setup config" to configure authentication information in ~/.oci/config file. (terraform by default looks for this file if no explicit authentication is configured for terraform)

## Terraform Commands

### Init

```
terraform init
```

- This command parses all *.tf files and finds what terraform plugins, modules are used in the files and then downloads them to .terraform folder.

### Plan & Apply

```
terraform plan
```

This command parses all *.tf files and builds an inmemory state and shows them as a plan in console/terminal. Plan is nothing but list of action that are going to be done to create a set of resources.

```
terraform apply
```

Command "apply" is same as "plan" except that it will create the resources at the end.

